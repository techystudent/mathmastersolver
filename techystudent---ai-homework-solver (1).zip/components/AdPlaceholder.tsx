import React from 'react';

interface AdPlaceholderProps {
  slot: string;
  format?: 'auto' | 'rectangle' | 'horizontal';
  label?: string;
  className?: string;
}

export const AdPlaceholder: React.FC<AdPlaceholderProps> = ({ slot, format = 'auto', label = 'Advertisement', className = '' }) => {
  return (
    <div className={`w-full my-4 flex flex-col items-center justify-center bg-gray-100 dark:bg-gray-800 border-2 border-dashed border-gray-300 dark:border-gray-700 rounded-lg p-4 ${className} no-print`}>
      <span className="text-xs text-gray-400 uppercase tracking-widest mb-2">{label}</span>
      <div className="text-center text-gray-500 dark:text-gray-400 text-sm">
        <p className="font-semibold">Google AdSense Space</p>
        <p className="text-xs mt-1">Slot ID: {slot}</p>
        <p className="text-xs">Format: {format}</p>
      </div>
    </div>
  );
};
