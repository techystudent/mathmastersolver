import React from 'react';

export const LegalLayout: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
  <div className="max-w-4xl mx-auto px-4 py-12 prose dark:prose-invert">
    <h1 className="text-3xl font-bold mb-8 text-primary-700 dark:text-primary-500">{title}</h1>
    <div className="bg-white dark:bg-gray-800 p-8 rounded-xl shadow-sm border border-gray-100 dark:border-gray-700">
      {children}
    </div>
  </div>
);

export const AboutPage = () => (
  <LegalLayout title="About Us">
    <p>Welcome to <strong>TechyStudent</strong>, your number one source for AI-powered educational assistance. We're dedicated to providing you the best automated tutoring experience, with a focus on dependability, step-by-step clarity, and multi-subject support.</p>
    <p>Founded in 2024, TechyStudent has come a long way from its beginnings. When we first started out, our passion for "making education accessible to everyone" drove us to start this tool.</p>
    <p>We hope you enjoy our products as much as we enjoy offering them to you. If you have any questions or comments, please don't hesitate to contact us.</p>
  </LegalLayout>
);

export const ContactPage = () => (
  <LegalLayout title="Contact Us">
    <p>We would love to hear from you!</p>
    <div className="mt-6">
      <h3 className="text-xl font-semibold mb-2">Email Us</h3>
      <p className="mb-4">support@techystudent.com</p>
      
      <h3 className="text-xl font-semibold mb-2">Mailing Address</h3>
      <p>123 Education Lane, Tech City, TC 90210</p>
    </div>
  </LegalLayout>
);

export const PrivacyPolicy = () => (
  <LegalLayout title="Privacy Policy">
    <p className="text-sm text-gray-500 mb-4">Last updated: October 26, 2023</p>
    <p>At TechyStudent, accessible from techystudent.com, one of our main priorities is the privacy of our visitors. This Privacy Policy document contains types of information that is collected and recorded by TechyStudent and how we use it.</p>
    <h3>Log Files</h3>
    <p>TechyStudent follows a standard procedure of using log files. These files log visitors when they visit websites. The information collected by log files includes internet protocol (IP) addresses, browser type, Internet Service Provider (ISP), date and time stamp, referring/exit pages, and possibly the number of clicks.</p>
    <h3>Cookies and Web Beacons</h3>
    <p>Like any other website, TechyStudent uses 'cookies'. These cookies are used to store information including visitors' preferences, and the pages on the website that the visitor accessed or visited.</p>
    <h3>Google DoubleClick DART Cookie</h3>
    <p>Google is one of a third-party vendor on our site. It also uses cookies, known as DART cookies, to serve ads to our site visitors based upon their visit to www.website.com and other sites on the internet.</p>
  </LegalLayout>
);

export const TermsConditions = () => (
  <LegalLayout title="Terms & Conditions">
    <p>Welcome to TechyStudent!</p>
    <p>These terms and conditions outline the rules and regulations for the use of TechyStudent's Website.</p>
    <p>By accessing this website we assume you accept these terms and conditions. Do not continue to use TechyStudent if you do not agree to take all of the terms and conditions stated on this page.</p>
    <h3>License</h3>
    <p>Unless otherwise stated, TechyStudent and/or its licensors own the intellectual property rights for all material on TechyStudent. All intellectual property rights are reserved.</p>
  </LegalLayout>
);

export const Disclaimer = () => (
  <LegalLayout title="Disclaimer">
    <p>The information provided by TechyStudent ("we," "us," or "our") on this website is for general informational and educational purposes only. All information on the Site is provided in good faith, however we make no representation or warranty of any kind, express or implied, regarding the accuracy, adequacy, validity, reliability, availability, or completeness of any information on the Site.</p>
    <div className="bg-yellow-50 dark:bg-yellow-900/20 border-l-4 border-yellow-500 p-4 my-4">
      <p className="font-bold text-yellow-800 dark:text-yellow-200">Educational Warning</p>
      <p className="text-sm text-yellow-700 dark:text-yellow-300 mt-1">
        This tool provides AI-generated solutions for educational support only. Students should verify steps before submitting homework. This tool should not be used for cheating on exams or graded assessments.
      </p>
    </div>
  </LegalLayout>
);
