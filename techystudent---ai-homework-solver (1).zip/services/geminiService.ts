import { GoogleGenAI } from "@google/genai";
import { SYSTEM_INSTRUCTION } from '../constants';

// Initialize Gemini Client
// Note: In a real deployment, ensure process.env.API_KEY is set.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const generateSolution = async (
  textInput: string,
  imageBase64: string | null,
  language: string = 'English'
): Promise<string> => {
  try {
    // Using gemini-3-pro-preview for better reasoning on Math/STEM tasks
    const modelId = 'gemini-3-pro-preview'; 
    
    const parts: any[] = [];

    // Add Image if present
    if (imageBase64) {
      // Remove data URL prefix if present to get raw base64
      const base64Data = imageBase64.replace(/^data:image\/\w+;base64,/, "");
      parts.push({
        inlineData: {
          data: base64Data,
          mimeType: 'image/png' // Assuming PNG or standard image formats
        }
      });
    }

    // Add Text Prompt - Simplified to prevent conversational triggers
    const promptText = `
      Input Question: ${textInput ? textInput : '[Analyze image]'}
      Target Language: ${language}
      Output Requirement: Provide ONLY the steps and final answer as per system instructions. Do NOT restate the problem.
    `;
    
    parts.push({ text: promptText });

    const response = await ai.models.generateContent({
      model: modelId,
      contents: {
        parts: parts
      },
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.1, // Very low temperature for strict factual output
      }
    });

    if (!response.text) {
      throw new Error("No solution generated. Please try again.");
    }

    return response.text;

  } catch (error) {
    console.error("Gemini API Error:", error);
    throw new Error("Failed to generate solution. Please check your internet connection or API key.");
  }
};